var v = WScript.CreateObject("WScript.Shell");
v.Run('{ACOMMAND}');